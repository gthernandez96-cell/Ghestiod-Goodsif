import sys
import os

# Auto-resolución de PYTHONPATH cuando el usuario ejecuta directamente pages.py en el IDE
_current_dir = os.path.dirname(os.path.abspath(__file__))
_backend_dir = os.path.abspath(os.path.join(_current_dir, "../../"))
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)

# Configurar valores por defecto para desarrollo local antes de cargar SQLAlchemy
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./pos.db")
os.environ.setdefault("DATABASE_URL_SYNC", "sqlite:///./pos.db")
os.environ.setdefault("SECRET_KEY", "clave-secreta-pos-2024")

from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
import uuid

from app.core.database import get_db
from app.models.sale import SaleOrder
from app.models.cashier import CashierSession
from app.models.company import Company, Branch
from app.models.user import User
from app.models.fel import FELDocument

router = APIRouter()

# Directorio absoluto de templates (backend/app/templates)
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "../templates"))

templates = Jinja2Templates(directory=TEMPLATES_DIR)


@router.get("/", response_class=HTMLResponse)
async def redirect_to_dashboard(request: Request):
    return RedirectResponse(url="/dashboard")


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse(request=request, name="auth/login.html")


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    return templates.TemplateResponse(request=request, name="dashboard/index.html")


@router.get("/pos", response_class=HTMLResponse)
async def pos_page(request: Request):
    return templates.TemplateResponse(request=request, name="pos/index.html")


@router.get("/inventory", response_class=HTMLResponse)
async def inventory_page(request: Request):
    return templates.TemplateResponse(request=request, name="inventory/index.html")


@router.get("/purchases", response_class=HTMLResponse)
async def purchases_page(request: Request):
    return templates.TemplateResponse(request=request, name="purchases/index.html")


@router.get("/transfers", response_class=HTMLResponse)
async def transfers_page(request: Request):
    return templates.TemplateResponse(request=request, name="transfers/index.html")


@router.get("/customers", response_class=HTMLResponse)
async def customers_page(request: Request):
    return templates.TemplateResponse(request=request, name="customers/index.html")


@router.get("/reports", response_class=HTMLResponse)
async def reports_page(request: Request):
    return templates.TemplateResponse(request=request, name="reports/index.html")


@router.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    return templates.TemplateResponse(request=request, name="settings/index.html")


@router.get("/mfg", response_class=HTMLResponse)
async def mfg_page(request: Request):
    return templates.TemplateResponse(request=request, name="mfg/index.html")


@router.get("/accounting", response_class=HTMLResponse)
async def accounting_page(request: Request):
    return templates.TemplateResponse(request=request, name="accounting/index.html")


@router.get("/invoicing", response_class=HTMLResponse)
async def invoicing_page(request: Request):
    return templates.TemplateResponse(request=request, name="invoicing/index.html")


@router.get("/hr", response_class=HTMLResponse)
async def hr_page(request: Request):
    return templates.TemplateResponse(request=request, name="hr/index.html")


@router.get("/audit", response_class=HTMLResponse)
async def audit_page(request: Request):
    return templates.TemplateResponse(request=request, name="audit/index.html")


@router.get("/quotes", response_class=HTMLResponse)
async def quotes_page(request: Request):
    return templates.TemplateResponse(request=request, name="quotes/index.html")


@router.get("/ap", response_class=HTMLResponse)
async def ap_page(request: Request):
    return templates.TemplateResponse(request=request, name="ap/index.html")


# ===== TICKETS & IMPRESIÓN =====
@router.get("/sales/{sale_id}/ticket", response_class=HTMLResponse)
async def sale_ticket_page(
    sale_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """Renderizar ticket térmico 80mm de una venta."""
    try:
        s_uuid = uuid.UUID(sale_id)
    except ValueError:
        return HTMLResponse("ID de venta inválido", status_code=400)

    stmt = (
        select(SaleOrder)
        .options(selectinload(SaleOrder.lines), selectinload(SaleOrder.payments), selectinload(SaleOrder.branch))
        .where(SaleOrder.id == s_uuid)
    )
    res = await db.execute(stmt)
    sale = res.scalar_one_or_none()

    if not sale:
        # Fallback dummy sale if testing with generated number
        dummy_sale = {
            "number": sale_id,
            "sale_date": None,
            "customer_name": "CONSUMIDOR FINAL",
            "customer_nit": "CF",
            "lines": [],
            "subtotal": 0.0,
            "tax_amount": 0.0,
            "total": 0.0,
            "payments": [],
        }
        dummy_company = {"name": "POS EMPRESARIAL", "nit": "12345678-9"}
        dummy_branch = {"name": "Sucursal Central", "address": "Guatemala"}
        return templates.TemplateResponse(
            request=request,
            name="pos/ticket_receipt.html",
            context={"sale": dummy_sale, "company": dummy_company, "branch": dummy_branch, "fel": None, "hasattr": hasattr}
        )

    # Fetch company and branch
    comp_res = await db.execute(select(Company).where(Company.id == sale.company_id))
    company = comp_res.scalar_one_or_none()

    fel_res = await db.execute(select(FELDocument).where(FELDocument.sale_id == sale.id))
    fel = fel_res.scalar_one_or_none()

    return templates.TemplateResponse(
        request=request,
        name="pos/ticket_receipt.html",
        context={
            "sale": sale,
            "company": company,
            "branch": sale.branch,
            "fel": fel,
            "hasattr": hasattr
        }
    )


@router.get("/cashier/sessions/{session_id}/z-report", response_class=HTMLResponse)
async def cashier_z_report(
    session_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """Renderizar el reporte de Cierre Z de una sesión de caja."""
    try:
        s_uuid = uuid.UUID(session_id)
    except ValueError:
        return HTMLResponse("ID de sesión inválido", status_code=400)

    stmt = (
        select(CashierSession)
        .options(selectinload(CashierSession.user), selectinload(CashierSession.branch))
        .where(CashierSession.id == s_uuid)
    )
    res = await db.execute(stmt)
    session = res.scalar_one_or_none()

    if not session:
        return HTMLResponse("Sesión no encontrada", status_code=404)

    comp_res = await db.execute(select(Company).limit(1))
    company = comp_res.scalar_one_or_none()

    return templates.TemplateResponse(
        request=request,
        name="pos/z_report.html",
        context={
            "session": session,
            "user": session.user,
            "branch": session.branch,
            "company": company,
        }
    )


if __name__ == "__main__":
    import uvicorn
    os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./pos.db")
    os.environ.setdefault("DATABASE_URL_SYNC", "sqlite:///./pos.db")
    os.environ.setdefault("SECRET_KEY", "clave-secreta-pos-2024")
    print("🚀 Iniciando POS Empresarial desde pages.py...")
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
