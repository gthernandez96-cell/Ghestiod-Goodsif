"""API v1 — Contabilidad."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.accounting import Account, JournalEntry, JournalEntryLine

router = APIRouter(prefix="/accounting")


# ===== SCHEMAS =====
class JournalEntryIn(BaseModel):
    concept: str
    amount: Decimal
    journal: str = "Ventas"


class JournalEntryLineOut(BaseModel):
    account_code: str
    account_name: str
    debit: float
    credit: float


class JournalEntryOut(BaseModel):
    id: str
    number: str
    journal: str
    concept: str
    debit: float
    credit: float
    state: str

    class Config:
        from_attributes = True


# ===== HELPERS =====
async def _ensure_basic_accounts(db: AsyncSession, company_id: uuid.UUID):
    """Asegurar la existencia de cuentas contables básicas de demo."""
    basic_accounts = [
        ("1101", "Caja General y Bancos", "asset"),
        ("4000", "Ventas de Panadería", "income"),
        ("5000", "Materia Prima e Insumos", "expense"),
        ("1105", "Clientes por Cobrar", "asset"),
        ("2101", "Proveedores por Pagar", "liability"),
    ]

    accounts = {}
    for code, name, acc_type in basic_accounts:
        stmt = select(Account).where(
            Account.code == code,
            Account.company_id == company_id,
            Account.is_deleted == False
        ).limit(1)
        res = await db.execute(stmt)
        acc = res.scalar_one_or_none()
        if not acc:
            acc = Account(
                company_id=company_id,
                code=code,
                name=name,
                account_type=acc_type
            )
            db.add(acc)
            await db.flush()
        accounts[code] = acc
    return accounts


# ===== ENDPOINTS =====
@router.get("/entries", response_model=List[JournalEntryOut])
async def list_journal_entries(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar asientos contables."""
    company_uuid = uuid.UUID(str(current_user.company_id))
    await _ensure_basic_accounts(db, company_uuid)

    stmt = (
        select(JournalEntry)
        .options(selectinload(JournalEntry.lines).selectinload(JournalEntryLine.account))
        .where(
            JournalEntry.company_id == company_uuid,
            JournalEntry.is_deleted == False
        )
        .order_by(JournalEntry.created_at.desc())
    )
    res = await db.execute(stmt)
    entries = res.scalars().all()

    out = []
    for entry in entries:
        # Calcular total de debe y haber
        total_debit = sum(Decimal(str(line.debit or 0)) for line in entry.lines)
        total_credit = sum(Decimal(str(line.credit or 0)) for line in entry.lines)

        out.append(
            JournalEntryOut(
                id=str(entry.id),
                number=entry.number,
                journal=entry.journal,
                concept=entry.concept,
                debit=float(max(total_debit, total_credit)),  # Mostrar el saldo de la partida
                credit=float(total_credit),
                state=entry.state
            )
        )
    return out


@router.post("/entries", response_model=JournalEntryOut)
async def create_journal_entry(
    data: JournalEntryIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Registrar un nuevo asiento contable manual de partida doble."""
    company_uuid = uuid.UUID(str(current_user.company_id))
    accounts = await _ensure_basic_accounts(db, company_uuid)

    stmt_count = select(JournalEntry).where(JournalEntry.company_id == company_uuid)
    res_count = await db.execute(stmt_count)
    seq = len(res_count.scalars().all()) + 1

    entry = JournalEntry(
        company_id=company_uuid,
        number=f"MISC/2026/{seq:04d}",
        journal=data.journal,
        concept=data.concept,
        date=datetime.now(timezone.utc),
        state="posted"
    )
    db.add(entry)
    await db.flush()

    # Partida doble simple según el diario
    if data.journal == "Ventas":
        # Debe: Caja General (1101) | Haber: Ventas de Panadería (4000)
        line_debit = JournalEntryLine(
            entry_id=entry.id,
            account_id=accounts["1101"].id,
            debit=data.amount,
            credit=Decimal("0.0")
        )
        line_credit = JournalEntryLine(
            entry_id=entry.id,
            account_id=accounts["4000"].id,
            debit=Decimal("0.0"),
            credit=data.amount
        )
    else:
        # Debe: Materia Prima (5000) | Haber: Caja General (1101)
        line_debit = JournalEntryLine(
            entry_id=entry.id,
            account_id=accounts["5000"].id,
            debit=data.amount,
            credit=Decimal("0.0")
        )
        line_credit = JournalEntryLine(
            entry_id=entry.id,
            account_id=accounts["1101"].id,
            debit=Decimal("0.0"),
            credit=data.amount
        )

    db.add_all([line_debit, line_credit])
    await db.commit()
    await db.refresh(entry)

    return JournalEntryOut(
        id=str(entry.id),
        number=entry.number,
        journal=entry.journal,
        concept=entry.concept,
        debit=float(data.amount),
        credit=float(data.amount),
        state=entry.state
    )
