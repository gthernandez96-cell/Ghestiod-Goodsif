"""API v1 — Cuentas por Pagar (AP)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone, timedelta
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.ap import SupplierBill
from app.models.partner import Partner, PartnerType

router = APIRouter(prefix="/ap")


# ===== SCHEMAS =====
class SupplierBillIn(BaseModel):
    supplier: str
    number: str
    total: Decimal


class SupplierBillOut(BaseModel):
    id: str
    number: str
    supplier: str
    due_date: str
    total: float
    balance: float
    state: str

    class Config:
        from_attributes = True


# ===== ENDPOINTS =====
@router.get("/bills", response_model=List[SupplierBillOut])
async def list_supplier_bills(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar facturas de proveedores (cuentas por pagar)."""
    company_uuid = uuid.UUID(str(current_user.company_id))

    stmt = (
        select(SupplierBill)
        .options(selectinload(SupplierBill.supplier))
        .where(
            SupplierBill.company_id == company_uuid,
            SupplierBill.is_deleted == False
        )
        .order_by(SupplierBill.created_at.desc())
    )
    res = await db.execute(stmt)
    bills = res.scalars().all()

    return [
        SupplierBillOut(
            id=str(b.id),
            number=b.number,
            supplier=b.supplier.name if b.supplier else "Proveedor Genérico",
            due_date=b.due_date.strftime("%Y-%m-%d") if b.due_date else "Vence Hoy",
            total=float(b.total),
            balance=float(b.balance),
            state="paid" if b.balance == 0 else "open"
        )
        for b in bills
    ]


@router.post("/bills", response_model=SupplierBillOut)
async def create_supplier_bill(
    data: SupplierBillIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Registrar una factura de proveedor."""
    company_uuid = uuid.UUID(str(current_user.company_id))

    # Buscar si ya existe el proveedor, o crear uno nuevo
    stmt_p = select(Partner).where(
        Partner.name == data.supplier,
        Partner.partner_type == PartnerType.SUPPLIER,
        Partner.company_id == company_uuid
    ).limit(1)
    res_p = await db.execute(stmt_p)
    supplier = res_p.scalar_one_or_none()

    if not supplier:
        supplier = Partner(
            company_id=company_uuid,
            partner_type=PartnerType.SUPPLIER,
            name=data.supplier,
            nit="CF",
            is_company=True
        )
        db.add(supplier)
        await db.flush()

    due = datetime.now(timezone.utc) + timedelta(days=30)

    bill = SupplierBill(
        company_id=company_uuid,
        supplier_id=supplier.id,
        number=data.number or f"BILL/2026/{uuid.uuid4().hex[:4].upper()}",
        due_date=due,
        total=data.total,
        balance=data.total,
        state="open"
    )
    db.add(bill)
    await db.commit()
    await db.refresh(bill)

    return SupplierBillOut(
        id=str(bill.id),
        number=bill.number,
        supplier=supplier.name,
        due_date=due.strftime("%Y-%m-%d"),
        total=float(bill.total),
        balance=float(bill.balance),
        state=bill.state
    )


@router.post("/bills/{bill_id}/pay")
async def pay_supplier_bill(
    bill_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Registrar el pago total de una factura de proveedor."""
    try:
        bill_uuid = uuid.UUID(bill_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de factura inválido")

    stmt = select(SupplierBill).where(
        SupplierBill.id == bill_uuid,
        SupplierBill.company_id == current_user.company_id,
        SupplierBill.is_deleted == False
    )
    res = await db.execute(stmt)
    bill = res.scalar_one_or_none()

    if not bill:
        raise HTTPException(status_code=404, detail="Factura de proveedor no encontrada")

    # Pagar la factura
    bill.balance = Decimal("0.0")
    bill.state = "paid"
    await db.commit()

    return {"status": "ok", "message": f"Pago registrado. Saldo pendiente: Q 0.00"}
