"""API v1 — Control de Caja y Sesiones de Cajero."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List, Dict
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.cashier import CashierSession, SessionState, CashMovement, CashMovementType, PaymentMethod

router = APIRouter(prefix="/cashier")


# ===== SCHEMAS =====
class OpenSessionIn(BaseModel):
    branch_id: str
    pos_id: Optional[str] = None
    opening_amount: Decimal = Decimal("0")
    denominations: Optional[Dict[str, int]] = None
    notes: Optional[str] = None


class CloseSessionIn(BaseModel):
    closing_amount_real: Decimal
    denominations: Optional[Dict[str, int]] = None
    notes: Optional[str] = None


class CashMovementIn(BaseModel):
    session_id: str
    move_type: str = "cash_in"  # "cash_in" or "cash_out"
    amount: Decimal
    reason: str
    payment_method: str = "cash"


def _generate_session_number() -> str:
    now = datetime.now()
    seq = str(uuid.uuid4().int)[:6]
    return f"SESS-{now.strftime('%Y%m%d')}-{seq}"


# ===== ENDPOINTS =====
@router.get("/sessions/active")
async def get_active_session(
    branch_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener la sesión de caja activa del usuario actual."""
    stmt = select(CashierSession).where(
        CashierSession.user_id == current_user.id,
        CashierSession.state == SessionState.OPEN
    )

    if branch_id:
        try:
            stmt = stmt.where(CashierSession.branch_id == uuid.UUID(branch_id))
        except ValueError:
            pass

    stmt = stmt.order_by(CashierSession.opened_at.desc()).limit(1)
    res = await db.execute(stmt)
    session = res.scalar_one_or_none()

    if not session:
        return {"has_active_session": False, "session": None}

    opening = float(session.opening_balance or 0)
    sales = float(session.total_sales or 0)
    cash_in = float(session.total_cash_in or 0)
    cash_out = float(session.total_cash_out or 0)
    returns = float(session.total_returns or 0)
    expected = opening + cash_in + sales - cash_out - returns

    return {
        "has_active_session": True,
        "session": {
            "id": str(session.id),
            "session_number": session.session_number,
            "branch_id": str(session.branch_id),
            "opened_at": session.opened_at.isoformat() if session.opened_at else None,
            "opening_balance": opening,
            "opening_amount": opening,
            "total_sales": sales,
            "total_cash_in": cash_in,
            "total_cash_out": cash_out,
            "expected_cash": expected,
            "state": session.state.value if hasattr(session.state, 'value') else str(session.state),
        }
    }


@router.get("/sessions/")
async def list_sessions(
    branch_id: Optional[str] = Query(None),
    limit: int = Query(20, le=100),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar historial de sesiones de caja."""
    stmt = (
        select(CashierSession)
        .options(selectinload(CashierSession.user), selectinload(CashierSession.branch))
        .order_by(CashierSession.opened_at.desc())
        .limit(limit)
    )

    if branch_id:
        try:
            stmt = stmt.where(CashierSession.branch_id == uuid.UUID(branch_id))
        except ValueError:
            pass

    res = await db.execute(stmt)
    sessions = res.scalars().all()

    return [
        {
            "id": str(s.id),
            "session_number": s.session_number,
            "user_name": s.user.full_name if s.user else "N/A",
            "branch_name": s.branch.name if s.branch else "N/A",
            "state": s.state.value if hasattr(s.state, 'value') else str(s.state),
            "opened_at": s.opened_at.isoformat() if s.opened_at else None,
            "closed_at": s.closed_at.isoformat() if s.closed_at else None,
            "opening_balance": float(s.opening_balance or 0),
            "closing_balance_real": float(s.closing_balance_real or 0),
            "closing_difference": float(s.closing_difference or 0),
            "total_sales": float(s.total_sales or 0),
        }
        for s in sessions
    ]


@router.post("/open")
@router.post("/sessions/")
async def open_session(
    data: OpenSessionIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Apertura de una nueva sesión de caja."""
    try:
        b_uuid = uuid.UUID(data.branch_id)
    except Exception:
        # Fallback to first available branch if branch_id string is invalid
        from app.models.company import Branch
        b_res = await db.execute(select(Branch.id).limit(1))
        b_uuid = b_res.scalar_one_or_none()
        if not b_uuid:
            raise HTTPException(status_code=400, detail="Sucursal no encontrada")

    # Verificar si ya tiene sesión abierta
    active_stmt = select(CashierSession).where(
        CashierSession.user_id == current_user.id,
        CashierSession.state == SessionState.OPEN,
        CashierSession.branch_id == b_uuid
    )
    active_res = await db.execute(active_stmt)
    existing_sess = active_res.scalar_one_or_none()
    if existing_sess:
        return {
            "id": str(existing_sess.id),
            "number": existing_sess.session_number,
            "opening_balance": float(existing_sess.opening_balance or 0),
            "status": "opened",
            "message": "Sesión ya estaba abierta"
        }

    session = CashierSession(
        branch_id=b_uuid,
        user_id=current_user.id,
        pos_id=uuid.UUID(data.pos_id) if (data.pos_id and len(data.pos_id) == 36) else None,
        session_number=_generate_session_number(),
        state=SessionState.OPEN,
        opened_at=datetime.now(timezone.utc),
        opening_balance=data.opening_amount,
        opening_notes=data.notes,
        opening_denominations=data.denominations or {},
    )
    db.add(session)
    await db.flush()

    # Registrar movimiento inicial de apertura
    initial_move = CashMovement(
        session_id=session.id,
        move_type=CashMovementType.OPEN_BALANCE,
        payment_method=PaymentMethod.CASH,
        amount=data.opening_amount,
        reference="Fondo de Apertura",
        notes=data.notes,
        user_id=current_user.id,
    )
    db.add(initial_move)
    await db.commit()
    await db.refresh(session)

    return {
        "id": str(session.id),
        "number": session.session_number,
        "opening_balance": float(session.opening_balance),
        "status": "opened",
    }


@router.post("/sessions/{session_id}/close")
async def close_session(
    session_id: str,
    data: CloseSessionIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Cierre de sesión de caja y arqueo."""
    try:
        s_uuid = uuid.UUID(session_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de sesión inválido")

    stmt = select(CashierSession).where(CashierSession.id == s_uuid)
    res = await db.execute(stmt)
    session = res.scalar_one_or_none()

    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada")

    if session.state == SessionState.CLOSED:
        raise HTTPException(status_code=400, detail="La sesión ya fue cerrada")

    # Calcular saldo esperado = saldo inicial + entradas + ventas efectivo - salidas - devoluciones
    expected = (
        (session.opening_balance or Decimal("0"))
        + (session.total_cash_in or Decimal("0"))
        + (session.total_sales or Decimal("0"))
        - (session.total_cash_out or Decimal("0"))
        - (session.total_returns or Decimal("0"))
    )

    difference = data.closing_amount_real - expected

    session.state = SessionState.CLOSED
    session.closed_at = datetime.now(timezone.utc)
    session.closing_balance_expected = expected
    session.closing_balance_real = data.closing_amount_real
    session.closing_difference = difference
    session.closing_denominations = data.denominations or {}
    session.closing_notes = data.notes

    # Registrar movimiento final
    close_move = CashMovement(
        session_id=session.id,
        move_type=CashMovementType.CLOSE_BALANCE,
        payment_method=PaymentMethod.CASH,
        amount=data.closing_amount_real,
        reference="Arqueo de Cierre",
        notes=data.notes,
        user_id=current_user.id,
    )
    db.add(close_move)
    await db.commit()

    return {
        "id": str(session.id),
        "session_number": session.session_number,
        "closing_balance_expected": float(expected),
        "closing_balance_real": float(data.closing_amount_real),
        "difference": float(difference),
        "closing_difference": float(difference),
        "status": "closed",
        "z_report_url": f"/cashier/sessions/{session.id}/z-report"
    }


@router.post("/movements/")
async def add_cash_movement(
    data: CashMovementIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Registrar un ingreso o retiro de efectivo en caja."""
    try:
        s_uuid = uuid.UUID(data.session_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de sesión inválido")

    stmt = select(CashierSession).where(CashierSession.id == s_uuid)
    res = await db.execute(stmt)
    session = res.scalar_one_or_none()

    if not session or session.state != SessionState.OPEN:
        raise HTTPException(status_code=400, detail="Sesión no encontrada o no está abierta")

    m_type = CashMovementType.CASH_IN if data.move_type.lower() == "cash_in" else CashMovementType.CASH_OUT

    move = CashMovement(
        session_id=session.id,
        move_type=m_type,
        payment_method=PaymentMethod.CASH,
        amount=data.amount,
        reference=data.reason,
        user_id=current_user.id,
    )
    db.add(move)

    if m_type == CashMovementType.CASH_IN:
        session.total_cash_in = (session.total_cash_in or Decimal("0")) + data.amount
    else:
        session.total_cash_out = (session.total_cash_out or Decimal("0")) + data.amount

    await db.commit()
    return {"id": str(move.id), "status": "ok", "move_type": m_type.value, "amount": float(data.amount)}
