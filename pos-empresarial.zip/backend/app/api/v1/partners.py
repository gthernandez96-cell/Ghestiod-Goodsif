"""API v1 — Clientes y Proveedores."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.partner import Partner, PartnerType, CreditStatus

router = APIRouter(prefix="/partners")


class PartnerCreateIn(BaseModel):
    name: str
    nit: Optional[str] = "CF"
    cui: Optional[str] = None
    trade_name: Optional[str] = None
    partner_type: str = "customer"
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = "Guatemala"
    is_company: bool = False
    credit_limit: Decimal = Decimal("0")
    payment_days: int = 0
    notes: Optional[str] = None


class PartnerUpdateIn(BaseModel):
    name: Optional[str] = None
    nit: Optional[str] = None
    trade_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    credit_limit: Optional[Decimal] = None
    payment_days: Optional[int] = None
    is_active: Optional[bool] = None


class CreditPaymentIn(BaseModel):
    amount: Decimal
    payment_method: str = "cash"
    reference: Optional[str] = None
    notes: Optional[str] = None


@router.get("/")
async def list_partners(
    search: Optional[str] = Query(None),
    partner_type: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(True),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar y buscar clientes o proveedores."""
    stmt = select(Partner).where(Partner.company_id == current_user.company_id)

    if is_active is not None:
        stmt = stmt.where(Partner.is_active == is_active)

    if partner_type:
        try:
            pt_enum = PartnerType(partner_type.lower())
            stmt = stmt.where(or_(Partner.partner_type == pt_enum, Partner.partner_type == PartnerType.BOTH))
        except ValueError:
            pass

    if search:
        pattern = f"%{search}%"
        stmt = stmt.where(
            or_(
                Partner.name.ilike(pattern),
                Partner.nit.ilike(pattern),
                Partner.phone.ilike(pattern),
                Partner.email.ilike(pattern),
            )
        )

    stmt = stmt.order_by(Partner.name)
    res = await db.execute(stmt)
    partners = res.scalars().all()

    items = [
        {
            "id": str(p.id),
            "name": p.name,
            "nit": p.nit or "CF",
            "cui": p.cui or "",
            "trade_name": p.trade_name or "",
            "partner_type": p.partner_type.value if hasattr(p.partner_type, 'value') else str(p.partner_type),
            "email": p.email or "",
            "phone": p.phone or "",
            "address": p.address or "",
            "city": p.city or "Guatemala",
            "credit_limit": float(p.credit_limit or 0),
            "balance": float(p.balance or 0),
            "is_active": p.is_active,
        }
        for p in partners
    ]

    return {"items": items, "total": len(items)}


@router.get("/lookup-nit/{nit}")
async def lookup_partner_by_nit(
    nit: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Buscar un cliente por NIT para facturación rápida en POS."""
    nit_clean = nit.strip().replace("-", "").upper()

    if nit_clean == "CF" or not nit_clean:
        return {
            "found": True,
            "items": [{"nit": "CF", "name": "CONSUMIDOR FINAL", "email": "", "address": "CIUDAD"}]
        }

    stmt = select(Partner).where(
        Partner.company_id == current_user.company_id,
        or_(
            Partner.nit.ilike(nit.strip()),
            Partner.nit.ilike(nit_clean),
            func.replace(Partner.nit, "-", "").ilike(nit_clean)
        )
    ).limit(1)
    res = await db.execute(stmt)
    partner = res.scalar_one_or_none()

    if partner:
        return {
            "found": True,
            "items": [{
                "id": str(partner.id),
                "nit": partner.nit,
                "name": partner.name,
                "email": partner.email or "",
                "address": partner.address or "",
            }]
        }

    return {"found": False, "items": []}


@router.get("/credits")
async def get_customer_credits(
    search: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener resumen de cuentas por cobrar y créditos de clientes."""
    stmt = select(Partner).where(
        Partner.company_id == current_user.company_id,
        Partner.is_active == True,
        or_(Partner.credit_limit > 0, Partner.balance > 0)
    )
    if search:
        s = f"%{search}%"
        stmt = stmt.where(or_(Partner.name.ilike(s), Partner.nit.ilike(s), Partner.phone.ilike(s)))

    res = await db.execute(stmt)
    partners = res.scalars().all()

    items = []
    total_credit_limit = Decimal("0")
    total_debt = Decimal("0")

    for p in partners:
        c_limit = Decimal(str(p.credit_limit or 0))
        c_balance = Decimal(str(p.balance or 0))
        c_available = max(Decimal("0"), c_limit - c_balance)

        total_credit_limit += c_limit
        total_debt += c_balance

        items.append({
            "id": str(p.id),
            "name": p.name,
            "nit": p.nit,
            "phone": p.phone,
            "email": p.email,
            "credit_limit": float(c_limit),
            "balance": float(c_balance),
            "available_credit": float(c_available),
            "payment_days": p.payment_days or 30,
            "credit_status": p.credit_status.value if hasattr(p.credit_status, "value") else str(p.credit_status)
        })

    return {
        "items": items,
        "total_credit_limit": float(total_credit_limit),
        "total_debt": float(total_debt),
        "total_available": float(max(Decimal("0"), total_credit_limit - total_debt))
    }


@router.get("/{partner_id}")
async def get_partner(
    partner_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener detalle de un cliente/proveedor."""
    try:
        p_uuid = uuid.UUID(partner_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de socio inválido")

    stmt = select(Partner).where(Partner.id == p_uuid, Partner.company_id == current_user.company_id)
    res = await db.execute(stmt)
    p = res.scalar_one_or_none()

    if not p:
        raise HTTPException(status_code=404, detail="Socio no encontrado")

    return {
        "id": str(p.id),
        "name": p.name,
        "nit": p.nit,
        "cui": p.cui,
        "trade_name": p.trade_name,
        "partner_type": p.partner_type.value if hasattr(p.partner_type, 'value') else str(p.partner_type),
        "email": p.email,
        "phone": p.phone,
        "address": p.address,
        "city": p.city,
        "credit_limit": float(p.credit_limit or 0),
        "balance": float(p.balance or 0),
        "is_active": p.is_active,
        "notes": p.notes,
    }


@router.post("/")
async def create_partner(
    data: PartnerCreateIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Crear un cliente o proveedor."""
    try:
        pt_enum = PartnerType(data.partner_type.lower())
    except ValueError:
        pt_enum = PartnerType.CUSTOMER

    partner = Partner(
        company_id=current_user.company_id,
        name=data.name,
        nit=data.nit or "CF",
        cui=data.cui,
        trade_name=data.trade_name,
        partner_type=pt_enum,
        email=data.email,
        phone=data.phone,
        address=data.address,
        city=data.city or "Guatemala",
        is_company=data.is_company,
        credit_limit=data.credit_limit,
        payment_days=data.payment_days,
        notes=data.notes,
    )
    db.add(partner)
    await db.commit()
    await db.refresh(partner)

    return {"id": str(partner.id), "name": partner.name, "nit": partner.nit, "status": "created"}


@router.put("/{partner_id}")
async def update_partner(
    partner_id: str,
    data: PartnerUpdateIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Actualizar datos de cliente/proveedor."""
    try:
        p_uuid = uuid.UUID(partner_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de socio inválido")

    stmt = select(Partner).where(Partner.id == p_uuid, Partner.company_id == current_user.company_id)
    res = await db.execute(stmt)
    p = res.scalar_one_or_none()

    if not p:
        raise HTTPException(status_code=404, detail="Socio no encontrado")

    if data.name is not None: p.name = data.name
    if data.nit is not None: p.nit = data.nit
    if data.trade_name is not None: p.trade_name = data.trade_name
    if data.email is not None: p.email = data.email
    if data.phone is not None: p.phone = data.phone
    if data.address is not None: p.address = data.address
    if data.city is not None: p.city = data.city
    if data.credit_limit is not None: p.credit_limit = data.credit_limit
    if data.payment_days is not None: p.payment_days = data.payment_days
    if data.is_active is not None: p.is_active = data.is_active

    await db.commit()
    return {"id": str(p.id), "status": "updated"}


@router.post("/{partner_id}/credit-payments")
async def pay_customer_credit(
    partner_id: str,
    data: CreditPaymentIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Registrar un abono o pago a la deuda del cliente."""
    try:
        p_uuid = uuid.UUID(partner_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de socio inválido")

    stmt = select(Partner).where(Partner.id == p_uuid, Partner.company_id == current_user.company_id)
    res = await db.execute(stmt)
    partner = res.scalar_one_or_none()

    if not partner:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="El monto a abonar debe ser mayor a cero")

    current_balance = Decimal(str(partner.balance or 0))
    new_balance = max(Decimal("0"), current_balance - data.amount)
    partner.balance = new_balance

    await db.commit()

    credit_limit = Decimal(str(partner.credit_limit or 0))
    available = max(Decimal("0"), credit_limit - new_balance)

    return {
        "partner_id": str(partner.id),
        "partner_name": partner.name,
        "amount_paid": float(data.amount),
        "previous_balance": float(current_balance),
        "new_balance": float(new_balance),
        "available_credit": float(available),
        "status": "payment_registered"
    }
