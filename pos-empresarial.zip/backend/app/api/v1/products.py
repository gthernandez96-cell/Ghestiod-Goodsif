"""API v1 — Productos y Categorías."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.product import Product, ProductCategory, ProductType, TrackingMethod, UnitOfMeasure
from app.models.inventory import StockQuant

router = APIRouter(prefix="/products")


def _val_to_str(val) -> str:
    if val is None:
        return ""
    if hasattr(val, "value"):
        return str(val.value)
    return str(val)


# ===== SCHEMAS =====
class CategoryCreateIn(BaseModel):
    name: str
    code: Optional[str] = None
    description: Optional[str] = None
    parent_id: Optional[str] = None
    tax_rate: Decimal = Decimal("12.00")


class ProductCreateIn(BaseModel):
    name: str
    internal_ref: Optional[str] = None
    barcode: Optional[str] = None
    category_id: Optional[str] = None
    description: Optional[str] = None
    product_type: str = "product"
    tracking: str = "none"
    sale_price: Decimal = Decimal("0")
    cost_price: Decimal = Decimal("0")
    min_price: Decimal = Decimal("0")
    tax_rate: Decimal = Decimal("12.00")
    includes_tax: bool = True
    min_stock: Decimal = Decimal("0")
    max_stock: Decimal = Decimal("0")
    is_active: bool = True
    can_be_sold: bool = True
    can_be_purchased: bool = True
    image_url: Optional[str] = None


class ProductUpdateIn(BaseModel):
    name: Optional[str] = None
    internal_ref: Optional[str] = None
    barcode: Optional[str] = None
    category_id: Optional[str] = None
    description: Optional[str] = None
    sale_price: Optional[Decimal] = None
    cost_price: Optional[Decimal] = None
    min_stock: Optional[Decimal] = None
    is_active: Optional[bool] = None
    image_url: Optional[str] = None


# ===== CATEGORIES ENDPOINTS =====
@router.get("/categories")
async def list_categories(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar todas las categorías de productos."""
    stmt = (
        select(ProductCategory)
        .where(ProductCategory.company_id == current_user.company_id)
        .order_by(ProductCategory.name)
    )
    result = await db.execute(stmt)
    categories = result.scalars().all()

    return [
        {
            "id": str(c.id),
            "name": c.name,
            "code": c.code,
            "description": c.description,
            "parent_id": str(c.parent_id) if c.parent_id else None,
            "tax_rate": float(c.tax_rate) if c.tax_rate else 12.0,
            "is_active": c.is_active,
        }
        for c in categories
    ]


@router.post("/categories")
async def create_category(
    data: CategoryCreateIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Crear una nueva categoría."""
    category = ProductCategory(
        company_id=current_user.company_id,
        name=data.name,
        code=data.code,
        description=data.description,
        parent_id=uuid.UUID(data.parent_id) if data.parent_id else None,
        tax_rate=data.tax_rate,
    )
    db.add(category)
    await db.commit()
    await db.refresh(category)
    return {"id": str(category.id), "name": category.name, "status": "created"}


# ===== PRODUCTS ENDPOINTS =====
@router.get("/")
async def list_products(
    search: Optional[str] = Query(None),
    category_id: Optional[str] = Query(None),
    warehouse_id: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(True),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar productos con filtrado y stock global/por bodega."""
    stmt = select(Product).options(selectinload(Product.category)).where(Product.company_id == current_user.company_id)

    if is_active is not None:
        stmt = stmt.where(Product.is_active == is_active)

    if category_id:
        try:
            stmt = stmt.where(Product.category_id == uuid.UUID(category_id))
        except ValueError:
            pass

    if search:
        search_pattern = f"%{search}%"
        stmt = stmt.where(
            or_(
                Product.name.ilike(search_pattern),
                Product.internal_ref.ilike(search_pattern),
                Product.barcode.ilike(search_pattern),
            )
        )

    stmt = stmt.order_by(Product.name)
    result = await db.execute(stmt)
    products = result.scalars().all()

    # Obtener stock global por producto
    product_ids = [p.id for p in products]
    stock_map = {}
    if product_ids:
        quant_stmt = select(
            StockQuant.product_id,
            func.sum(StockQuant.qty_on_hand).label("total_stock")
        ).where(StockQuant.product_id.in_(product_ids))

        if warehouse_id:
            try:
                quant_stmt = quant_stmt.where(StockQuant.warehouse_id == uuid.UUID(warehouse_id))
            except ValueError:
                pass

        quant_stmt = quant_stmt.group_by(StockQuant.product_id)
        quant_res = await db.execute(quant_stmt)
        for p_id, total in quant_res.all():
            stock_map[str(p_id)] = float(total or 0)

    items = []
    for p in products:
        p_id_str = str(p.id)
        items.append({
            "id": p_id_str,
            "name": p.name,
            "internal_ref": p.internal_ref or "",
            "barcode": p.barcode or "",
            "description": p.description or "",
            "category_id": str(p.category_id) if p.category_id else None,
            "category_name": p.category.name if p.category else "General",
            "sale_price": float(p.sale_price or 0),
            "cost_price": float(p.cost_price or 0),
            "min_price": float(p.min_price or 0),
            "tax_rate": float(p.tax_rate or 12.0),
            "includes_tax": p.includes_tax,
            "min_stock": float(p.min_stock or 0),
            "stock": stock_map.get(p_id_str, 0.0),
            "product_type": _val_to_str(p.product_type),
            "tracking": _val_to_str(p.tracking),
            "is_active": p.is_active,
            "can_be_sold": p.can_be_sold,
            "image_url": p.image_url,
        })

    return {"items": items, "total": len(items)}


@router.get("/{product_id}")
async def get_product(
    product_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener detalle de un producto."""
    try:
        p_uuid = uuid.UUID(product_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de producto inválido")

    stmt = select(Product).options(selectinload(Product.category)).where(
        Product.id == p_uuid, Product.company_id == current_user.company_id
    )
    res = await db.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")

    # Stock por bodega
    quant_stmt = select(
        StockQuant.warehouse_id, func.sum(StockQuant.qty_on_hand)
    ).where(StockQuant.product_id == p_uuid).group_by(StockQuant.warehouse_id)
    quant_res = await db.execute(quant_stmt)
    stock_by_warehouse = {str(wh_id): float(qty) for wh_id, qty in quant_res.all()}

    return {
        "id": str(p.id),
        "name": p.name,
        "internal_ref": p.internal_ref,
        "barcode": p.barcode,
        "description": p.description,
        "category_id": str(p.category_id) if p.category_id else None,
        "category_name": p.category.name if p.category else None,
        "sale_price": float(p.sale_price or 0),
        "cost_price": float(p.cost_price or 0),
        "min_stock": float(p.min_stock or 0),
        "tax_rate": float(p.tax_rate or 12.0),
        "is_active": p.is_active,
        "stock_by_warehouse": stock_by_warehouse,
        "total_stock": sum(stock_by_warehouse.values()),
        "image_url": p.image_url,
    }


@router.post("/")
async def create_product(
    data: ProductCreateIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Crear un producto."""
    category_uuid = uuid.UUID(data.category_id) if data.category_id else None

    try:
        p_type = ProductType(data.product_type)
    except ValueError:
        p_type = ProductType.PRODUCT

    try:
        p_track = TrackingMethod(data.tracking)
    except ValueError:
        p_track = TrackingMethod.NONE

    product = Product(
        company_id=current_user.company_id,
        name=data.name,
        internal_ref=data.internal_ref,
        barcode=data.barcode,
        category_id=category_uuid,
        description=data.description,
        product_type=p_type,
        tracking=p_track,
        sale_price=data.sale_price,
        cost_price=data.cost_price,
        min_price=data.min_price,
        tax_rate=data.tax_rate,
        includes_tax=data.includes_tax,
        min_stock=data.min_stock,
        max_stock=data.max_stock,
        is_active=data.is_active,
        can_be_sold=data.can_be_sold,
        can_be_purchased=data.can_be_purchased,
        image_url=data.image_url,
    )
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return {"id": str(product.id), "name": product.name, "status": "created"}


@router.put("/{product_id}")
async def update_product(
    product_id: str,
    data: ProductUpdateIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Actualizar un producto existente."""
    try:
        p_uuid = uuid.UUID(product_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de producto inválido")

    stmt = select(Product).where(Product.id == p_uuid, Product.company_id == current_user.company_id)
    res = await db.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")

    if data.name is not None: p.name = data.name
    if data.internal_ref is not None: p.internal_ref = data.internal_ref
    if data.barcode is not None: p.barcode = data.barcode
    if data.category_id is not None: p.category_id = uuid.UUID(data.category_id) if data.category_id else None
    if data.description is not None: p.description = data.description
    if data.sale_price is not None: p.sale_price = data.sale_price
    if data.cost_price is not None: p.cost_price = data.cost_price
    if data.min_stock is not None: p.min_stock = data.min_stock
    if data.is_active is not None: p.is_active = data.is_active
    if data.image_url is not None: p.image_url = data.image_url

    await db.commit()
    return {"id": str(p.id), "status": "updated"}


@router.get("/{product_id}/barcode-label")
async def get_product_barcode_label(
    product_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Generar etiqueta adhesiva con código de barras e info del producto."""
    try:
        p_uuid = uuid.UUID(product_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de producto inválido")

    stmt = select(Product).where(Product.id == p_uuid, Product.company_id == current_user.company_id)
    res = await db.execute(stmt)
    p = res.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")

    barcode_val = p.barcode or p.internal_ref or str(p.id)[:8]

    html_content = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Etiqueta — {p.name}</title>
<style>
  @page {{ size: 50mm 30mm; margin: 0; }}
  body {{
    width: 48mm;
    height: 28mm;
    margin: 1mm auto;
    font-family: sans-serif;
    text-align: center;
    border: 1px dashed #ccc;
    box-sizing: border-box;
    padding: 2mm;
  }}
  .title {{ font-size: 10px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
  .price {{ font-size: 14px; font-weight: 900; color: #000; margin: 2px 0; }}
  .barcode-img {{ width: 100%; height: 28px; object-fit: contain; }}
  .code-text {{ font-size: 9px; font-family: monospace; letter-spacing: 1px; }}
  @media print {{ body {{ border: none; }} .no-print {{ display: none; }} }}
</style>
</head>
<body onload="window.print()">
  <div class="no-print" style="margin-bottom:4px"><button onclick="window.print()">🖨️ Imprimir Etiquetas</button></div>
  <div class="title">{p.name}</div>
  <div class="price">Q {float(p.sale_price or 0):.2f}</div>
  <img class="barcode-img" src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data={barcode_val}" alt="Barcode">
  <div class="code-text">{barcode_val}</div>
</body>
</html>"""
    from fastapi.responses import HTMLResponse
    return HTMLResponse(content=html_content)
