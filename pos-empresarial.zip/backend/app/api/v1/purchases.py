"""API v1 — Compras y Recepción de Mercadería."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.purchase import PurchaseOrder, PurchaseOrderLine, GoodsReceipt, GoodsReceiptLine, PurchaseState
from app.models.partner import Partner
from app.models.company import Warehouse
from app.models.inventory import StockMoveType
from app.services.inventory_service import InventoryService

router = APIRouter(prefix="/purchases")


# ===== SCHEMAS =====
class POLineIn(BaseModel):
    product_id: str
    product_name: str
    qty: Decimal
    unit_price: Decimal
    tax_rate: Decimal = Decimal("12.00")


class CreatePOIn(BaseModel):
    branch_id: str
    warehouse_id: str
    supplier_id: str
    supplier_ref: Optional[str] = None
    lines: List[POLineIn]
    notes: Optional[str] = None
    payment_terms: Optional[str] = None


class ReceiveLineIn(BaseModel):
    line_id: str
    qty_received: Decimal


class ReceivePOIn(BaseModel):
    receipt_lines: List[ReceiveLineIn]
    notes: Optional[str] = None


def _generate_po_number() -> str:
    now = datetime.now()
    seq = str(uuid.uuid4().int)[:6]
    return f"OC-{now.strftime('%Y%m%d')}-{seq}"


# ===== ENDPOINTS =====
@router.get("/")
async def list_purchases(
    branch_id: Optional[str] = Query(None),
    supplier_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar órdenes de compra."""
    stmt = (
        select(PurchaseOrder)
        .options(selectinload(PurchaseOrder.supplier))
        .where(PurchaseOrder.company_id == current_user.company_id)
        .order_by(PurchaseOrder.order_date.desc())
    )

    if branch_id:
        try:
            stmt = stmt.where(PurchaseOrder.branch_id == uuid.UUID(branch_id))
        except ValueError:
            pass

    if supplier_id:
        try:
            stmt = stmt.where(PurchaseOrder.supplier_id == uuid.UUID(supplier_id))
        except ValueError:
            pass

    res = await db.execute(stmt)
    purchases = res.scalars().all()

    return [
        {
            "id": str(po.id),
            "number": po.number,
            "supplier_name": po.supplier.name if po.supplier else "N/A",
            "branch_id": str(po.branch_id),
            "date": po.order_date.strftime("%Y-%m-%d") if po.order_date else "",
            "state": po.state.value if hasattr(po.state, 'value') else str(po.state),
            "total": float(po.total or 0),
            "notes": po.notes or "",
        }
        for po in purchases
    ]


@router.get("/{purchase_id}")
async def get_purchase(
    purchase_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener detalle de una orden de compra."""
    try:
        p_uuid = uuid.UUID(purchase_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de compra inválido")

    stmt = (
        select(PurchaseOrder)
        .options(selectinload(PurchaseOrder.supplier), selectinload(PurchaseOrder.lines))
        .where(PurchaseOrder.id == p_uuid, PurchaseOrder.company_id == current_user.company_id)
    )
    res = await db.execute(stmt)
    po = res.scalar_one_or_none()

    if not po:
        raise HTTPException(status_code=404, detail="Orden de compra no encontrada")

    return {
        "id": str(po.id),
        "number": po.number,
        "supplier_id": str(po.supplier_id),
        "supplier_name": po.supplier.name if po.supplier else "N/A",
        "branch_id": str(po.branch_id),
        "warehouse_id": str(po.warehouse_id),
        "state": po.state.value if hasattr(po.state, 'value') else str(po.state),
        "subtotal": float(po.subtotal or 0),
        "tax_amount": float(po.tax_amount or 0),
        "total": float(po.total or 0),
        "order_date": po.order_date.isoformat() if po.order_date else None,
        "lines": [
            {
                "id": str(line.id),
                "product_id": str(line.product_id),
                "product_name": line.product_name,
                "qty_ordered": float(line.qty_ordered or 0),
                "qty_received": float(line.qty_received or 0),
                "unit_price": float(line.unit_price or 0),
                "subtotal": float(line.subtotal or 0),
                "total": float(line.total or 0),
            }
            for line in po.lines
        ],
    }


@router.post("/")
async def create_purchase(
    data: CreatePOIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Crear una orden de compra en estado borradores/confirmada."""
    try:
        b_uuid = uuid.UUID(data.branch_id)
        w_uuid = uuid.UUID(data.warehouse_id)
        s_uuid = uuid.UUID(data.supplier_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="IDs de sucursal, bodega o proveedor inválidos")

    subtotal = Decimal("0")
    tax_amount = Decimal("0")
    po_lines = []

    for item in data.lines:
        line_subtotal = item.qty * item.unit_price
        line_tax = line_subtotal * (item.tax_rate / Decimal("100"))
        line_total = line_subtotal + line_tax

        subtotal += line_subtotal
        tax_amount += line_tax

        po_line = PurchaseOrderLine(
            product_id=uuid.UUID(item.product_id),
            product_name=item.product_name,
            qty_ordered=item.qty,
            qty_pending=item.qty,
            qty_received=Decimal("0"),
            unit_price=item.unit_price,
            tax_rate=item.tax_rate,
            subtotal=line_subtotal,
            tax_amount=line_tax,
            total=line_total,
        )
        po_lines.append(po_line)

    po = PurchaseOrder(
        company_id=current_user.company_id,
        branch_id=b_uuid,
        warehouse_id=w_uuid,
        supplier_id=s_uuid,
        user_id=current_user.id,
        number=_generate_po_number(),
        supplier_ref=data.supplier_ref,
        state=PurchaseState.CONFIRMED,
        order_date=datetime.now(timezone.utc),
        subtotal=subtotal,
        tax_amount=tax_amount,
        total=subtotal + tax_amount,
        notes=data.notes,
        payment_terms=data.payment_terms,
        lines=po_lines,
    )

    db.add(po)
    await db.commit()
    await db.refresh(po)

    return {"id": str(po.id), "number": po.number, "status": "created", "total": float(po.total)}


@router.post("/{purchase_id}/receive")
async def receive_purchase(
    purchase_id: str,
    data: ReceivePOIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Recibir mercadería de una Orden de Compra y actualizar inventario/costos."""
    try:
        p_uuid = uuid.UUID(purchase_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de compra inválido")

    stmt = (
        select(PurchaseOrder)
        .options(selectinload(PurchaseOrder.lines))
        .where(PurchaseOrder.id == p_uuid, PurchaseOrder.company_id == current_user.company_id)
    )
    res = await db.execute(stmt)
    po = res.scalar_one_or_none()

    if not po:
        raise HTTPException(status_code=404, detail="Orden de compra no encontrada")

    inv_service = InventoryService(db)
    receipt_lines = []

    # Map inputs
    recv_map = {r.line_id: r.qty_received for r in data.receipt_lines}

    all_received = True

    for line in po.lines:
        line_id_str = str(line.id)
        qty_to_recv = recv_map.get(line_id_str, line.qty_ordered - (line.qty_received or Decimal("0")))

        if qty_to_recv > 0:
            line.qty_received = (line.qty_received or Decimal("0")) + qty_to_recv
            line.qty_pending = max(Decimal("0"), line.qty_ordered - line.qty_received)

            # Crear movimiento de inventario ENTRADA
            await inv_service.create_move(
                warehouse_id=po.warehouse_id,
                product_id=line.product_id,
                move_type=StockMoveType.PURCHASE,
                qty=qty_to_recv,
                unit_cost=line.unit_price,
                reference=f"Recepción {po.number}",
                reference_id=po.id,
                user_id=current_user.id,
            )

        if line.qty_received < line.qty_ordered:
            all_received = False

    po.state = PurchaseState.RECEIVED if all_received else PurchaseState.PARTIAL
    po.received_date = datetime.now(timezone.utc)

    await db.commit()
    return {"id": str(po.id), "number": po.number, "state": po.state.value, "status": "received"}
