"""API v1 — Cotizaciones / Proformas."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.sale import SaleOrder, SaleState, SaleType
from app.models.partner import Partner

router = APIRouter(prefix="/quotes")


# ===== SCHEMAS =====
class QuoteIn(BaseModel):
    customer: str
    nit: str = "CF"
    total: Decimal


class QuoteOut(BaseModel):
    id: str
    number: str
    customer: str
    valid_until: str
    total: float
    state: str

    class Config:
        from_attributes = True


# ===== ENDPOINTS =====
@router.get("/", response_model=List[QuoteOut])
async def list_quotes(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar cotizaciones."""
    company_uuid = uuid.UUID(str(current_user.company_id))

    stmt = (
        select(SaleOrder)
        .where(
            SaleOrder.company_id == company_uuid,
            SaleOrder.sale_type == SaleType.QUOTE,
            SaleOrder.is_deleted == False
        )
        .order_by(SaleOrder.created_at.desc())
    )
    res = await db.execute(stmt)
    quotes = res.scalars().all()

    return [
        QuoteOut(
            id=str(q.id),
            number=q.number,
            customer=q.customer_name or "Consumidor Final",
            valid_until="15 días",
            total=float(q.total),
            state="converted" if q.state == SaleState.CONFIRMED else "sent"
        )
        for q in quotes
    ]


@router.post("/", response_model=QuoteOut)
async def create_quote(
    data: QuoteIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Generar una nueva cotización/proforma."""
    company_uuid = uuid.UUID(str(current_user.company_id))

    # Obtener branch y warehouse por defecto
    from app.models.company import Branch, Warehouse
    b_res = await db.execute(select(Branch.id).limit(1))
    branch_uuid = b_res.scalar_one_or_none()
    w_res = await db.execute(select(Warehouse.id).limit(1))
    warehouse_uuid = w_res.scalar_one_or_none()

    stmt_count = select(SaleOrder).where(
        SaleOrder.company_id == company_uuid,
        SaleOrder.sale_type == SaleType.QUOTE
    )
    res_count = await db.execute(stmt_count)
    seq = len(res_count.scalars().all()) + 1

    quote = SaleOrder(
        company_id=company_uuid,
        branch_id=branch_uuid,
        warehouse_id=warehouse_uuid,
        number=f"SO{seq:05d}",
        state=SaleState.DRAFT,
        sale_type=SaleType.QUOTE,
        sale_date=datetime.now(timezone.utc),
        customer_nit=data.nit,
        customer_name=data.customer,
        total=data.total,
        subtotal=data.total / Decimal("1.12"),  # Estimar subtotal sin IVA
        tax_amount=data.total - (data.total / Decimal("1.12")),
        user_id=current_user.id
    )
    db.add(quote)
    await db.commit()
    await db.refresh(quote)

    return QuoteOut(
        id=str(quote.id),
        number=quote.number,
        customer=quote.customer_name,
        valid_until="15 días",
        total=float(quote.total),
        state="sent"
    )


@router.post("/{quote_id}/convert")
async def convert_quote_to_sale(
    quote_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Convertir cotización en una venta confirmada y facturada."""
    try:
        q_uuid = uuid.UUID(quote_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de cotización inválido")

    stmt = select(SaleOrder).where(
        SaleOrder.id == q_uuid,
        SaleOrder.company_id == current_user.company_id,
        SaleOrder.is_deleted == False
    )
    res = await db.execute(stmt)
    quote = res.scalar_one_or_none()

    if not quote:
        raise HTTPException(status_code=404, detail="Cotización no encontrada")

    if quote.sale_type != SaleType.QUOTE:
        raise HTTPException(status_code=400, detail="El documento no es una cotización")

    # Convertir a venta activa y facturada
    quote.sale_type = SaleType.POS
    quote.state = SaleState.CONFIRMED
    await db.commit()

    return {"status": "ok", "message": f"Cotización {quote.number} convertida a venta exitosamente"}
