"""API v1 — Reportes y Exportación de Datos."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, cast, Date
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.sale import SaleOrder, SaleOrderLine, SaleState
from app.models.fel import FELDocument

router = APIRouter(prefix="/reports")


@router.get("/sales-by-period")
async def sales_by_period(
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Reporte de ventas agrupadas por fecha."""
    now = datetime.now(timezone.utc)
    try:
        s_date = datetime.fromisoformat(start_date) if (start_date and isinstance(start_date, str)) else (now - timedelta(days=30))
    except Exception:
        s_date = now - timedelta(days=30)

    try:
        e_date = datetime.fromisoformat(end_date) if (end_date and isinstance(end_date, str)) else now
    except Exception:
        e_date = now

    stmt = select(
        cast(SaleOrder.sale_date, Date).label("date"),
        func.count(SaleOrder.id).label("transactions"),
        func.sum(SaleOrder.subtotal).label("subtotal"),
        func.sum(SaleOrder.tax_amount).label("tax_amount"),
        func.sum(SaleOrder.total).label("total")
    ).where(
        SaleOrder.company_id == current_user.company_id,
        SaleOrder.sale_date >= s_date,
        SaleOrder.sale_date <= e_date,
        SaleOrder.state != SaleState.CANCELLED
    ).group_by(cast(SaleOrder.sale_date, Date)).order_by(cast(SaleOrder.sale_date, Date))

    res = await db.execute(stmt)
    rows = res.all()

    return [
        {
            "date": str(r.date),
            "transactions": int(r.transactions or 0),
            "subtotal": float(r.subtotal or 0),
            "tax_amount": float(r.tax_amount or 0),
            "total": float(r.total or 0),
        }
        for r in rows
    ]


@router.get("/fel-ledger")
async def fel_ledger_report(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Libro de ventas FEL para la SAT."""
    stmt = select(FELDocument).order_by(FELDocument.certified_at.desc())
    res = await db.execute(stmt)
    docs = res.scalars().all()

    return [
        {
            "fecha": d.certified_at.strftime("%Y-%m-%d") if d.certified_at else "",
            "tipo_dte": d.dte_type,
            "serie": d.series,
            "numero": d.number,
            "uuid": d.uuid,
            "nit_receptor": d.receiver_nit,
            "nombre_receptor": d.receiver_name,
            "subtotal": float((d.total or 0) / Decimal("1.12")),
            "iva": float((d.total or 0) - ((d.total or 0) / Decimal("1.12"))),
            "total": float(d.total or 0),
            "estado": d.status.value if hasattr(d.status, 'value') else str(d.status),
        }
        for d in docs
    ]
