"""API v1 — Ventas / POS."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.sale import SaleOrder, SaleOrderLine, SalePayment, SaleState, SaleType
from app.models.cashier import CashierSession, SessionState, CashMovementType, PaymentMethod, CashMovement
from app.models.company import Branch, Warehouse
from app.models.inventory import StockMoveType
from app.services.inventory_service import InventoryService
from app.services.fel_service import FELService

router = APIRouter(prefix="/sales")


# ===== SCHEMAS =====
class SaleLineIn(BaseModel):
    product_id: str
    variant_id: Optional[str] = None
    lot_id: Optional[str] = None
    product_name: str
    product_barcode: Optional[str] = None
    qty: Decimal
    unit_price: Decimal
    cost_price: Decimal = Decimal("0")
    discount_pct: Decimal = Decimal("0")
    tax_rate: Decimal = Decimal("12")
    uom_id: Optional[str] = None
    serial_number: Optional[str] = None


class SalePaymentIn(BaseModel):
    payment_method: str = "cash"
    amount: Decimal
    reference: Optional[str] = None
    card_last4: Optional[str] = None


class CreateSaleIn(BaseModel):
    branch_id: str
    warehouse_id: str
    cashier_session_id: Optional[str] = None
    customer_id: Optional[str] = None
    customer_nit: Optional[str] = "CF"
    customer_name: Optional[str] = "CONSUMIDOR FINAL"
    price_list_id: Optional[str] = None
    sale_type: str = "pos"
    lines: List[SaleLineIn]
    payments: List[SalePaymentIn]
    notes: Optional[str] = None
    generate_fel: bool = True


# ===== HELPERS =====
def _generate_sale_number(branch_code: str) -> str:
    """Generar número de venta único."""
    now = datetime.now()
    seq = str(uuid.uuid4().int)[:8]
    return f"{branch_code}-{now.strftime('%Y%m%d')}-{seq}"


# ===== ENDPOINTS =====
@router.post("/")
async def create_sale(
    data: CreateSaleIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Crear venta completa desde el POS."""
    inv_service = InventoryService(db)

    def to_uuid(val):
        if not val:
            return None
        if isinstance(val, uuid.UUID):
            return val
        try:
            return uuid.UUID(str(val))
        except Exception:
            return None

    company_uuid = current_user.company_id if isinstance(current_user.company_id, uuid.UUID) else to_uuid(current_user.company_id)
    user_uuid = current_user.id if isinstance(current_user.id, uuid.UUID) else to_uuid(current_user.id)
    branch_uuid = to_uuid(data.branch_id)
    warehouse_uuid = to_uuid(data.warehouse_id)
    customer_uuid = to_uuid(data.customer_id)
    session_uuid = to_uuid(data.cashier_session_id)
    price_list_uuid = to_uuid(data.price_list_id)

    # Validar y asegurar branch_uuid válido
    if branch_uuid:
        b_chk = await db.execute(select(Branch.id).where(Branch.id == branch_uuid))
        if not b_chk.scalar_one_or_none():
            branch_uuid = None
    if not branch_uuid:
        b_res = await db.execute(select(Branch.id).limit(1))
        branch_uuid = b_res.scalar_one_or_none()

    # Validar y asegurar warehouse_uuid válido
    if warehouse_uuid:
        w_chk = await db.execute(select(Warehouse.id).where(Warehouse.id == warehouse_uuid))
        if not w_chk.scalar_one_or_none():
            warehouse_uuid = None
    if not warehouse_uuid:
        w_res = await db.execute(select(Warehouse.id).limit(1))
        warehouse_uuid = w_res.scalar_one_or_none()

    # Crear la orden
    sale = SaleOrder(
        company_id=company_uuid,
        branch_id=branch_uuid,
        warehouse_id=warehouse_uuid,
        customer_id=customer_uuid,
        cashier_session_id=session_uuid,
        user_id=user_uuid,
        price_list_id=price_list_uuid,
        number=_generate_sale_number("POS"),
        state=SaleState.DRAFT,
        sale_type=SaleType(data.sale_type),
        sale_date=datetime.now(timezone.utc),
        customer_nit=data.customer_nit,
        customer_name=data.customer_name,
        notes=data.notes,
    )

    # Agregar líneas y calcular totales
    subtotal = Decimal("0")
    tax_amount = Decimal("0")
    discount_amount = Decimal("0")

    for line_data in data.lines:
        line = SaleOrderLine(
            product_id=to_uuid(line_data.product_id),
            variant_id=to_uuid(line_data.variant_id),
            lot_id=to_uuid(line_data.lot_id),
            uom_id=to_uuid(line_data.uom_id),
            serial_number=line_data.serial_number,
            product_name=line_data.product_name,
            product_barcode=line_data.product_barcode,
            qty=line_data.qty,
            unit_price=line_data.unit_price,
            cost_price=line_data.cost_price,
            discount_pct=line_data.discount_pct,
            tax_rate=line_data.tax_rate,
        )
        line.compute_totals()
        sale.lines.append(line)

        subtotal += line.subtotal
        tax_amount += line.tax_amount
        discount_amount += line.discount_amount

    sale.subtotal = subtotal
    sale.tax_amount = tax_amount
    sale.discount_amount = discount_amount
    sale.total = subtotal + tax_amount

    # Agregar pagos
    amount_paid = Decimal("0")
    for pay_data in data.payments:
        if pay_data.payment_method == "credit":
            if not customer_uuid:
                raise HTTPException(status_code=400, detail="Para venta a crédito debes seleccionar un cliente registrado")
            from app.models.partner import Partner
            p_res = await db.execute(select(Partner).where(Partner.id == customer_uuid))
            cust = p_res.scalar_one_or_none()
            if not cust or cust.nit == "CF":
                raise HTTPException(status_code=400, detail="No se puede otorgar crédito a Consumidor Final (CF). Selecciona un cliente registrado.")

            c_limit = Decimal(str(cust.credit_limit or 0))
            c_balance = Decimal(str(cust.balance or 0))
            available = max(Decimal("0"), c_limit - c_balance)

            if pay_data.amount > available:
                raise HTTPException(status_code=400, detail=f"Crédito insuficiente para {cust.name}. Crédito disponible: Q {float(available):.2f}")

            cust.balance = c_balance + pay_data.amount

        payment = SalePayment(
            payment_method=pay_data.payment_method,
            amount=pay_data.amount,
            reference=pay_data.reference,
            card_last4=pay_data.card_last4,
            session_id=session_uuid,
        )
        sale.payments.append(payment)
        amount_paid += pay_data.amount

    sale.amount_paid = amount_paid
    sale.amount_due = max(Decimal("0"), sale.total - amount_paid)

    # Cambiar estado
    sale.state = SaleState.PAID if sale.amount_due == 0 else SaleState.CONFIRMED

    # Buscar sesión de caja para registrar venta y movimientos en efectivo
    cash_paid = sum(p.amount for p in sale.payments if p.payment_method == "cash")
    session_obj = None
    if session_uuid:
        s_res = await db.execute(select(CashierSession).where(CashierSession.id == session_uuid))
        session_obj = s_res.scalar_one_or_none()

    if not session_obj and user_uuid and branch_uuid:
        s_res = await db.execute(
            select(CashierSession).where(
                CashierSession.user_id == user_uuid,
                CashierSession.branch_id == branch_uuid,
                CashierSession.state == SessionState.OPEN
            ).order_by(CashierSession.opened_at.desc()).limit(1)
        )
        session_obj = s_res.scalar_one_or_none()

    if session_obj:
        sale.cashier_session_id = session_obj.id
        if cash_paid > 0:
            session_obj.total_sales = (session_obj.total_sales or Decimal("0")) + cash_paid
            sale_move = CashMovement(
                session_id=session_obj.id,
                move_type=CashMovementType.SALE,
                payment_method=PaymentMethod.CASH,
                amount=cash_paid,
                reference=f"Venta {sale.number}",
                user_id=user_uuid,
            )
            db.add(sale_move)

    db.add(sale)
    await db.flush()

    # Descontar inventario
    for line in sale.lines:
        if warehouse_uuid and line.product_id:
            # Calcular cantidad convertida según la unidad de medida
            qty_inventory = line.qty
            if line.uom_id:
                from app.models.product import UnitOfMeasure
                uom_res = await db.execute(select(UnitOfMeasure).where(UnitOfMeasure.id == line.uom_id))
                uom = uom_res.scalar_one_or_none()
                if uom:
                    qty_inventory = line.qty * Decimal(str(uom.ratio))

            await inv_service.create_move(
                warehouse_id=warehouse_uuid,
                product_id=to_uuid(line.product_id),
                move_type=StockMoveType.SALE,
                qty=qty_inventory,
                unit_cost=line.cost_price,
                reference=sale.number,
                reference_id=sale.id,
                lot_id=to_uuid(line.lot_id),
                variant_id=to_uuid(line.variant_id),
                user_id=user_uuid,
                notes=f"N/S: {line.serial_number}" if line.serial_number else ""
            )

    # Generar FEL
    fel_doc = None
    if data.generate_fel:
        try:
            fel_service = FELService(db, current_user.company_id)
            # Cargar relaciones necesarias para FEL
            fel_doc = await fel_service.generate_dte(sale)
            sale.fel_uuid = fel_doc.uuid
            sale.fel_number = fel_doc.number
            sale.fel_series = fel_doc.series
            sale.fel_certified_at = fel_doc.certified_at
            sale.fel_status = fel_doc.status.value
        except Exception as e:
            # No fallar la venta si FEL falla — contingencia
            import logging
            logging.getLogger(__name__).error(f"FEL Error: {e}")

    await db.commit()

    return {
        "id": str(sale.id),
        "number": sale.number,
        "state": sale.state.value,
        "total": float(sale.total),
        "amount_paid": float(sale.amount_paid),
        "amount_due": float(sale.amount_due),
        "change": float(max(Decimal("0"), amount_paid - sale.total)),
        "fel_uuid": sale.fel_uuid,
        "fel_status": sale.fel_status,
        "lines_count": len(sale.lines),
    }


@router.get("/")
async def list_sales(
    branch_id: Optional[str] = None,
    state: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar ventas con filtros."""
    filters = [
        SaleOrder.company_id == current_user.company_id,
        SaleOrder.is_deleted == False,
    ]

    if branch_id:
        filters.append(SaleOrder.branch_id == branch_id)
    if state:
        filters.append(SaleOrder.state == state)
    if search:
        filters.append(
            (SaleOrder.number.ilike(f"%{search}%")) |
            (SaleOrder.customer_name.ilike(f"%{search}%")) |
            (SaleOrder.customer_nit.ilike(f"%{search}%"))
        )

    stmt = (
        select(SaleOrder)
        .where(and_(*filters))
        .order_by(SaleOrder.sale_date.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )

    count_stmt = select(func.count()).select_from(SaleOrder).where(and_(*filters))

    result = await db.execute(stmt)
    count_result = await db.execute(count_stmt)

    sales = result.scalars().all()
    total = count_result.scalar()

    return {
        "items": [
            {
                "id": str(s.id),
                "number": s.number,
                "state": s.state.value,
                "customer_name": s.customer_name,
                "customer_nit": s.customer_nit,
                "total": float(s.total),
                "sale_date": s.sale_date.isoformat() if s.sale_date else None,
                "fel_uuid": s.fel_uuid,
                "fel_status": s.fel_status,
            }
            for s in sales
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": (total + page_size - 1) // page_size,
    }


@router.get("/{sale_id}")
async def get_sale(
    sale_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener detalle de una venta."""
    result = await db.execute(
        select(SaleOrder)
        .options(selectinload(SaleOrder.lines), selectinload(SaleOrder.payments))
        .where(SaleOrder.id == sale_id, SaleOrder.is_deleted == False)
    )
    sale = result.scalar_one_or_none()
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")

    return {
        "id": str(sale.id),
        "number": sale.number,
        "state": sale.state.value,
        "sale_type": sale.sale_type.value,
        "sale_date": sale.sale_date.isoformat() if sale.sale_date else None,
        "customer_nit": sale.customer_nit,
        "customer_name": sale.customer_name,
        "subtotal": float(sale.subtotal),
        "tax_amount": float(sale.tax_amount),
        "discount_amount": float(sale.discount_amount),
        "total": float(sale.total),
        "amount_paid": float(sale.amount_paid),
        "amount_due": float(sale.amount_due),
        "fel_uuid": sale.fel_uuid,
        "fel_status": sale.fel_status,
        "notes": sale.notes,
        "lines": [
            {
                "id": str(l.id),
                "product_name": l.product_name,
                "qty": float(l.qty),
                "unit_price": float(l.unit_price),
                "discount_pct": float(l.discount_pct),
                "subtotal": float(l.subtotal),
                "tax_amount": float(l.tax_amount),
                "total": float(l.total),
            }
            for l in sale.lines
        ],
        "payments": [
            {
                "payment_method": p.payment_method,
                "amount": float(p.amount),
                "reference": p.reference,
            }
            for p in sale.payments
        ],
    }


@router.post("/{sale_id}/cancel")
async def cancel_sale(
    sale_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Cancelar una venta y revertir inventario."""
    result = await db.execute(
        select(SaleOrder)
        .options(selectinload(SaleOrder.lines))
        .where(SaleOrder.id == sale_id)
    )
    sale = result.scalar_one_or_none()
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")

    if sale.state == SaleState.CANCELLED:
        raise HTTPException(status_code=400, detail="La venta ya está cancelada")

    # Revertir movimientos de inventario
    inv_service = InventoryService(db)
    for line in sale.lines:
        await inv_service.create_move(
            warehouse_id=sale.warehouse_id,
            product_id=uuid.UUID(str(line.product_id)),
            move_type=StockMoveType.RETURN_SALE,
            qty=line.qty - line.qty_returned,
            reference=f"CANCEL-{sale.number}",
            reference_id=sale.id,
            user_id=current_user.id,
        )

    sale.state = SaleState.CANCELLED
    await db.commit()

    return {"message": f"Venta {sale.number} cancelada correctamente"}
