"""API v1 — Traslados Internos entre Bodegas."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import datetime, timezone
import uuid

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.transfer import Transfer, TransferLine, TransferState
from app.models.company import Warehouse
from app.models.inventory import StockMoveType
from app.services.inventory_service import InventoryService

router = APIRouter(prefix="/transfers")


# ===== SCHEMAS =====
class TransferLineIn(BaseModel):
    product_id: str
    product_name: str
    qty: Decimal


class CreateTransferIn(BaseModel):
    origin_branch_id: str
    origin_warehouse_id: str
    dest_branch_id: str
    dest_warehouse_id: str
    lines: List[TransferLineIn]
    notes: Optional[str] = None


def _generate_transfer_number() -> str:
    now = datetime.now()
    seq = str(uuid.uuid4().int)[:6]
    return f"TR-{now.strftime('%Y%m%d')}-{seq}"


# ===== ENDPOINTS =====
@router.get("/")
async def list_transfers(
    branch_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Listar solicitudes y traslados de inventario."""
    stmt = (
        select(Transfer)
        .options(selectinload(Transfer.origin_branch), selectinload(Transfer.dest_branch))
        .where(Transfer.company_id == current_user.company_id)
        .order_by(Transfer.request_date.desc())
    )

    if branch_id:
        try:
            b_uuid = uuid.UUID(branch_id)
            stmt = stmt.where((Transfer.origin_branch_id == b_uuid) | (Transfer.dest_branch_id == b_uuid))
        except ValueError:
            pass

    res = await db.execute(stmt)
    transfers = res.scalars().all()

    return [
        {
            "id": str(t.id),
            "number": t.number,
            "origin_branch_name": t.origin_branch.name if t.origin_branch else "N/A",
            "dest_branch_name": t.dest_branch.name if t.dest_branch else "N/A",
            "state": t.state.value if hasattr(t.state, 'value') else str(t.state),
            "date": t.request_date.strftime("%Y-%m-%d") if t.request_date else "",
            "notes": t.notes or "",
        }
        for t in transfers
    ]


@router.get("/{transfer_id}")
async def get_transfer(
    transfer_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Obtener detalle de un traslado."""
    try:
        t_uuid = uuid.UUID(transfer_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de traslado inválido")

    stmt = (
        select(Transfer)
        .options(
            selectinload(Transfer.origin_branch),
            selectinload(Transfer.dest_branch),
            selectinload(Transfer.lines)
        )
        .where(Transfer.id == t_uuid, Transfer.company_id == current_user.company_id)
    )
    res = await db.execute(stmt)
    t = res.scalar_one_or_none()

    if not t:
        raise HTTPException(status_code=404, detail="Traslado no encontrado")

    return {
        "id": str(t.id),
        "number": t.number,
        "origin_branch_id": str(t.origin_branch_id),
        "origin_branch_name": t.origin_branch.name if t.origin_branch else "N/A",
        "origin_warehouse_id": str(t.origin_warehouse_id),
        "dest_branch_id": str(t.dest_branch_id),
        "dest_branch_name": t.dest_branch.name if t.dest_branch else "N/A",
        "dest_warehouse_id": str(t.dest_warehouse_id),
        "state": t.state.value if hasattr(t.state, 'value') else str(t.state),
        "request_date": t.request_date.isoformat() if t.request_date else None,
        "lines": [
            {
                "id": str(line.id),
                "product_id": str(line.product_id),
                "product_name": line.product_name,
                "qty_requested": float(line.qty_requested or 0),
                "qty_sent": float(line.qty_sent or 0),
                "qty_received": float(line.qty_received or 0),
            }
            for line in t.lines
        ]
    }


@router.post("/")
async def create_transfer(
    data: CreateTransferIn,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Solicitar un traslado de mercadería."""
    try:
        ob_uuid = uuid.UUID(data.origin_branch_id)
        ow_uuid = uuid.UUID(data.origin_warehouse_id)
        db_uuid = uuid.UUID(data.dest_branch_id)
        dw_uuid = uuid.UUID(data.dest_warehouse_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="IDs de sucursales o bodegas inválidos")

    t_lines = [
        TransferLine(
            product_id=uuid.UUID(item.product_id),
            product_name=item.product_name,
            qty_requested=item.qty,
            qty_sent=Decimal("0"),
            qty_received=Decimal("0"),
        )
        for item in data.lines
    ]

    transfer = Transfer(
        company_id=current_user.company_id,
        origin_branch_id=ob_uuid,
        origin_warehouse_id=ow_uuid,
        dest_branch_id=db_uuid,
        dest_warehouse_id=dw_uuid,
        number=_generate_transfer_number(),
        state=TransferState.CONFIRMED,
        request_date=datetime.now(timezone.utc),
        requested_by=current_user.id,
        notes=data.notes,
        lines=t_lines,
    )

    db.add(transfer)
    await db.commit()
    await db.refresh(transfer)

    return {"id": str(transfer.id), "number": transfer.number, "status": "created"}


@router.post("/{transfer_id}/send")
async def send_transfer(
    transfer_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Despachar mercadería de la bodega de origen."""
    try:
        t_uuid = uuid.UUID(transfer_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de traslado inválido")

    stmt = (
        select(Transfer)
        .options(selectinload(Transfer.lines))
        .where(Transfer.id == t_uuid, Transfer.company_id == current_user.company_id)
    )
    res = await db.execute(stmt)
    t = res.scalar_one_or_none()

    if not t or t.state in [TransferState.SENT, TransferState.RECEIVED, TransferState.CANCELLED]:
        raise HTTPException(status_code=400, detail="Traslado no disponible para envío")

    inv_service = InventoryService(db)

    for line in t.lines:
        line.qty_sent = line.qty_requested
        # Descontar de bodega origen
        await inv_service.create_move(
            warehouse_id=t.origin_warehouse_id,
            product_id=line.product_id,
            move_type=StockMoveType.TRANSFER_OUT,
            qty=line.qty_sent,
            reference=f"Envío Traslado {t.number}",
            reference_id=t.id,
            user_id=current_user.id,
        )

    t.state = TransferState.SENT
    t.send_date = datetime.now(timezone.utc)
    t.sent_by = current_user.id

    await db.commit()
    return {"id": str(t.id), "number": t.number, "state": t.state.value, "status": "sent"}


@router.post("/{transfer_id}/receive")
async def receive_transfer(
    transfer_id: str,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Confirmar recepción de mercadería en bodega de destino."""
    try:
        t_uuid = uuid.UUID(transfer_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de traslado inválido")

    stmt = (
        select(Transfer)
        .options(selectinload(Transfer.lines))
        .where(Transfer.id == t_uuid, Transfer.company_id == current_user.company_id)
    )
    res = await db.execute(stmt)
    t = res.scalar_one_or_none()

    if not t or t.state == TransferState.RECEIVED:
        raise HTTPException(status_code=400, detail="Traslado no disponible para recepción")

    inv_service = InventoryService(db)

    for line in t.lines:
        line.qty_received = line.qty_sent or line.qty_requested
        # Ingresar a bodega destino
        await inv_service.create_move(
            warehouse_id=t.dest_warehouse_id,
            product_id=line.product_id,
            move_type=StockMoveType.TRANSFER_IN,
            qty=line.qty_received,
            reference=f"Recepción Traslado {t.number}",
            reference_id=t.id,
            user_id=current_user.id,
        )

    t.state = TransferState.RECEIVED
    t.receive_date = datetime.now(timezone.utc)
    t.received_by = current_user.id

    await db.commit()
    return {"id": str(t.id), "number": t.number, "state": t.state.value, "status": "received"}
