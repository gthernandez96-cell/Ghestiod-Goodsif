"""Modelos: Cuentas por Pagar (AP) y Facturas de Proveedores."""
from sqlalchemy import Column, String, ForeignKey, Numeric, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from app.models.base import BaseModel


class SupplierBill(BaseModel):
    """Factura de Proveedor para control de Cuentas por Pagar."""
    __tablename__ = "supplier_bills"

    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    supplier_id = Column(UUID(as_uuid=True), ForeignKey("partners.id"), nullable=False)
    number = Column(String(100), nullable=False, index=True)
    due_date = Column(DateTime(timezone=True))
    total = Column(Numeric(18, 4), nullable=False, default=0.0)
    balance = Column(Numeric(18, 4), nullable=False, default=0.0)
    state = Column(String(20), default="open")  # open, paid, cancelled

    # Relationships
    supplier = relationship("Partner", foreign_keys=[supplier_id])

    def __repr__(self):
        return f"<SupplierBill {self.number} - Balance: {self.balance}>"
