"""Pruebas de integración para la API v1 de POS Empresarial."""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert "app" in data
    assert "status" in data


def test_api_info():
    response = client.get("/api/v1/info")
    assert response.status_code == 200
    data = response.json()
    assert "environment" in data


def test_page_routes():
    pages = ["/login", "/dashboard", "/pos", "/inventory", "/purchases", "/transfers", "/customers", "/reports", "/settings"]
    for page in pages:
        res = client.get(page)
        assert res.status_code == 200
