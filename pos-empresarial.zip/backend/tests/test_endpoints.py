"""Pruebas de integración para endpoints API v1."""
import pytest
import asyncio
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import select
from app.main import app
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.models import Company, User, Role, Branch
import uuid

client = TestClient(app)

COMPANY_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")
USER_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")

token = create_access_token(data={"sub": str(USER_ID), "email": "test_admin@empresa.com", "company_id": str(COMPANY_ID)})
headers = {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module", autouse=True)
def setup_database():
    """Crear tablas y usuario inicial para los tests."""
    from app.core.database import engine

    async def _init():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        async_session = async_sessionmaker(engine, expire_on_commit=False)
        async with async_session() as session:
            comp_existing = await session.execute(select(Company).where(Company.id == COMPANY_ID))
            if not comp_existing.scalar_one_or_none():
                comp = Company(id=COMPANY_ID, name="Empresa Test API", nit="999888777")
                session.add(comp)

            existing = await session.execute(select(User).where(User.id == USER_ID))
            if not existing.scalar_one_or_none():
                user = User(
                    id=USER_ID,
                    company_id=COMPANY_ID,
                    email="test_admin@empresa.com",
                    username="test_admin",
                    full_name="Admin Test",
                    hashed_password=get_password_hash("Admin2024!"),
                    is_active=True,
                    is_superuser=True,
                )
                session.add(user)
                await session.commit()

    asyncio.run(_init())


def test_products_api():
    # 1. Crear categoría
    cat_res = client.post("/api/v1/products/categories", json={"name": "Bebidas Test", "code": "TEST-CAT"}, headers=headers)
    assert cat_res.status_code == 200
    cat_id = cat_res.json()["id"]

    # 2. Crear producto
    prod_res = client.post("/api/v1/products/", json={
        "name": "Coca Cola 355ml Test",
        "category_id": cat_id,
        "sale_price": 7.50,
        "cost_price": 4.50,
        "min_stock": 10
    }, headers=headers)
    assert prod_res.status_code == 200

    # 3. Listar productos
    list_res = client.get("/api/v1/products/?search=Test", headers=headers)
    assert list_res.status_code == 200
    assert len(list_res.json()["items"]) >= 1


def test_partners_api():
    # Crear cliente
    res = client.post("/api/v1/partners/", json={
        "name": "Cliente de Prueba API",
        "nit": "123456-7",
        "partner_type": "customer",
        "phone": "5555-1234"
    }, headers=headers)
    assert res.status_code == 200

    # Buscar por NIT
    lookup = client.get("/api/v1/partners/lookup-nit/123456-7", headers=headers)
    assert lookup.status_code == 200
    assert lookup.json()["found"] is True


def test_dashboard_api():
    kpis = client.get("/api/v1/dashboard/kpis", headers=headers)
    assert kpis.status_code == 200
    data = kpis.json()
    assert "sales_today" in data
    assert "low_stock" in data

    chart = client.get("/api/v1/dashboard/sales-chart", headers=headers)
    assert chart.status_code == 200
    assert "labels" in chart.json()


def test_ticket_and_zreport():
    test_uuid = str(uuid.uuid4())
    ticket_res = client.get(f"/sales/{test_uuid}/ticket")
    assert ticket_res.status_code == 200
    assert "DOCUMENTO TRIBUTARIO ELECTRÓNICO" in ticket_res.text


def test_barcode_label():
    prod_res = client.post("/api/v1/products/", json={"name": "Producto Barcode Test", "sale_price": 10.0}, headers=headers)
    assert prod_res.status_code == 200
    p_id = prod_res.json()["id"]

    label_res = client.get(f"/api/v1/products/{p_id}/barcode-label", headers=headers)
    assert label_res.status_code == 200
    assert "Etiqueta" in label_res.text


def test_customer_credit_and_payment():
    # 1. Crear cliente con crédito de Q 1000
    create_res = client.post("/api/v1/partners/", json={
        "name": "Cliente Crédito Test",
        "nit": "9876543-2",
        "phone": "5555-8888",
        "credit_limit": 1000.0,
        "payment_days": 30
    }, headers=headers)
    assert create_res.status_code == 200
    partner_id = create_res.json()["id"]

    # 2. Consultar créditos
    credits_res = client.get("/api/v1/partners/credits", headers=headers)
    assert credits_res.status_code == 200

    # 3. Registrar abono
    pay_res = client.post(f"/api/v1/partners/{partner_id}/credit-payments", json={
        "amount": 200.0,
        "payment_method": "cash",
        "reference": "Abono inicial"
    }, headers=headers)
    assert pay_res.status_code == 200
    assert pay_res.json()["amount_paid"] == 200.0


def test_pos_cashier_flow():
    # 0. Limpiar sesiones abiertas previas si existen
    act_chk = client.get("/api/v1/cashier/sessions/active", headers=headers)
    if act_chk.status_code == 200 and act_chk.json().get("has_active_session"):
        old_id = act_chk.json()["session"]["id"]
        client.post(f"/api/v1/cashier/sessions/{old_id}/close", json={"closing_amount_real": 0.0}, headers=headers)

    # 1. Apertura de caja
    open_res = client.post("/api/v1/cashier/open", json={
        "branch_id": str(COMPANY_ID),
        "opening_amount": 500.0,
        "notes": "Apertura inicial test"
    }, headers=headers)
    assert open_res.status_code == 200
    sess_data = open_res.json()
    sess_id = sess_data["id"]

    # 2. Consultar sesión activa
    act_res = client.get("/api/v1/cashier/sessions/active", headers=headers)
    assert act_res.status_code == 200
    assert act_res.json()["has_active_session"] is True
    assert act_res.json()["session"]["opening_balance"] == 500.0

    # 3. Realizar una venta vinculada a la sesión
    sale_res = client.post("/api/v1/sales/", json={
        "branch_id": str(COMPANY_ID),
        "warehouse_id": str(COMPANY_ID),
        "cashier_session_id": sess_id,
        "customer_nit": "CF",
        "customer_name": "CONSUMIDOR FINAL",
        "sale_type": "pos",
        "generate_fel": True,
        "lines": [{
            "product_id": str(uuid.uuid4()),
            "product_name": "Gaseosa Test 500ml",
            "qty": 2,
            "unit_price": 10.0,
            "cost_price": 5.0
        }],
        "payments": [{
            "payment_method": "cash",
            "amount": 22.4
        }]
    }, headers=headers)
    assert sale_res.status_code == 200
    sale_data = sale_res.json()
    assert sale_data["total"] == 22.4
    assert sale_data["fel_uuid"] is not None

    # 4. Verificar que se actualizó el total de ventas en la sesión
    act_res2 = client.get("/api/v1/cashier/sessions/active", headers=headers)
    assert act_res2.json()["session"]["total_sales"] == 22.4
    assert act_res2.json()["session"]["expected_cash"] == 522.4

    # 5. Cierre de caja y Z-Report
    close_res = client.post(f"/api/v1/cashier/sessions/{sess_id}/close", json={
        "closing_amount_real": 522.4,
        "notes": "Cierre perfecto"
    }, headers=headers)
    assert close_res.status_code == 200
    assert close_res.json()["closing_difference"] == 0.0

    # 6. Renderizado del reporte Z
    z_res = client.get(f"/cashier/sessions/{sess_id}/z-report")
    assert z_res.status_code == 200
    assert "REPORTE DE CIERRE Z" in z_res.text


