import sys
import os
import shutil
import zipfile

# 1. Rutas en PythonAnywhere
home_dir = "/home/gthernandez96"
zip_path = os.path.join(home_dir, "pos-empresarial.zip")
project_path = os.path.join(home_dir, "pos-empresarial")
backend_path = os.path.join(project_path, "backend")
user_site = "/home/gthernandez96/.local/lib/python3.10/site-packages"

# 2. Agregar user site-packages PRIMERO
if user_site not in sys.path:
    sys.path.insert(0, user_site)

# 3. Eliminar paquetes locales que interfieren
bad_dirs = [
    "fastapi", "pydantic", "pydantic_core", "pydantic_settings",
    "a2wsgi", "starlette", "annotated_types", "typing_inspection",
    "aiosqlite", "dotenv"
]
for bad in bad_dirs:
    bad_path = os.path.join(backend_path, bad)
    if os.path.exists(bad_path):
        shutil.rmtree(bad_path, ignore_errors=True)

# 4. Descomprimir ZIP si existe
if os.path.exists(zip_path):
    try:
        os.makedirs(project_path, exist_ok=True)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(project_path)
        try:
            os.remove(zip_path)
        except Exception:
            pass
    except Exception as e:
        sys.stderr.write(f"⚠️ Error unzipping: {e}\n")
    for bad in bad_dirs:
        bad_path = os.path.join(backend_path, bad)
        if os.path.exists(bad_path):
            shutil.rmtree(bad_path, ignore_errors=True)

# 5. Configurar PYTHONPATH
if backend_path not in sys.path:
    sys.path.insert(0, backend_path)
if project_path not in sys.path:
    sys.path.insert(0, project_path)

# 6. Variables de entorno
os.environ["DATABASE_URL"] = f"sqlite+aiosqlite:///{project_path}/pos.db"
os.environ["DATABASE_URL_SYNC"] = f"sqlite:///{project_path}/pos.db"
os.environ["SECRET_KEY"] = "clave-secreta-pos-empresarial-2026-prod"

# 7. Usar asgiref para adaptar ASGI -> WSGI (diseñado para Django Channels / FastAPI)
from asgiref.wsgi import WsgiToAsgi
from app.main import app as fastapi_app

# WsgiToAsgi es el wrapper estándar de Django que convierte WSGI→ASGI,
# pero necesitamos el inverso. Usamos run_coroutine_threadsafe directamente:
import asyncio
import threading

_loop = None
_loop_lock = threading.Lock()

def _get_or_create_loop():
    global _loop
    with _loop_lock:
        if _loop is None or not _loop.is_running():
            _loop = asyncio.new_event_loop()
            t = threading.Thread(target=_loop.run_forever, daemon=True)
            t.start()
        return _loop

async def _handle_asgi(scope, body):
    """Run FastAPI ASGI app and collect response."""
    response_started = {}
    response_body = []
    
    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}
    
    async def send(message):
        if message["type"] == "http.response.start":
            response_started["status"] = message["status"]
            response_started["headers"] = message.get("headers", [])
        elif message["type"] == "http.response.body":
            response_body.append(message.get("body", b""))
    
    await fastapi_app(scope, receive, send)
    return response_started, b"".join(response_body)

def application(environ, start_response):
    """WSGI entrypoint that runs FastAPI ASGI app synchronously."""
    # Build ASGI scope from WSGI environ
    scope = {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": environ.get("SERVER_PROTOCOL", "HTTP/1.1").split("/")[1],
        "method": environ.get("REQUEST_METHOD", "GET"),
        "headers": [
            (k.lower().replace("_", "-")[5:].encode() if k.startswith("HTTP_") else k.lower().replace("_", "-").encode(),
             v.encode())
            for k, v in environ.items()
            if k.startswith("HTTP_") or k in ("CONTENT_TYPE", "CONTENT_LENGTH")
            if v
        ],
        "path": environ.get("PATH_INFO", "/"),
        "raw_path": environ.get("PATH_INFO", "/").encode(),
        "root_path": environ.get("SCRIPT_NAME", ""),
        "scheme": environ.get("wsgi.url_scheme", "https"),
        "query_string": environ.get("QUERY_STRING", "").encode(),
        "server": (environ.get("SERVER_NAME", "localhost"), int(environ.get("SERVER_PORT", 443))),
    }
    
    # Read request body
    try:
        content_length = int(environ.get("CONTENT_LENGTH") or 0)
        body = environ["wsgi.input"].read(content_length) if content_length > 0 else b""
    except Exception:
        body = b""
    
    # Run async handler in dedicated event loop thread
    loop = _get_or_create_loop()
    future = asyncio.run_coroutine_threadsafe(_handle_asgi(scope, body), loop)
    try:
        response_started, response_body = future.result(timeout=30)
    except Exception as e:
        sys.stderr.write(f"❌ ASGI error: {e}\n")
        start_response("500 Internal Server Error", [("Content-Type", "text/plain")])
        return [str(e).encode()]
    
    status = f"{response_started.get('status', 500)} OK"
    headers = [
        (k.decode() if isinstance(k, bytes) else k,
         v.decode() if isinstance(v, bytes) else v)
        for k, v in response_started.get("headers", [])
    ]
    start_response(status, headers)
    return [response_body]
